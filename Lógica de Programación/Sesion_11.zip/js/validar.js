function validacampos(){
    var user = document.frmLogin.txtUusario.value;
    if(user === ""){
        alert("Por favor, digite el campo de usuario");
        document.frmLogin.txtUusario.focus();
        return false;
    }
    if((user.length > 8)){
        alert("El usuario es inválido");
        document.frmLogin.txtUsuario.focus();
        return false;
    }

    var pwd = document.frmLogin.txtPass.value;
    var exp = /[\W_]/;

    if(pwd === ""){
        alert("Por favor, digite la contraseña");
        document.frmLogin.txtPass.focus();
        return false;
    }
    else if((pwd.length > 3)){
        alert("La contraseña debe ser de 3 caracteres");
        document.frmLogin.txtPass.focus();
        return false;
    }
    else if(exp.test(pwd)){
        alert("La contraseña contiene caracteres ilegales");
        document.frmLogin.txtPass.focus();
        return false;
    }
    else{
        alert("Bienvenido al sistema");
        return true;
    }
}